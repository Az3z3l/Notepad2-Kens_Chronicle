## Server

- docker build -t notepad2 .
- docker run -p 80:3000 notepad2
- access the challenge on localhost

## Bot

- Requires puppeteer with latest version of chrome 